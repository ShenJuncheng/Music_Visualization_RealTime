# Music_Visualization_RealTime
RealTimeEmbedded_Project

https://github.com/WiringPi/WiringPi/tree/master/wiringPi
wiringpi元件驱动



reference:
* https://github.com/albanjoseph/Signapse
* https://twitter.com/BerndPorr/status/1516897303923204096
* https://www.hackster.io/fhdm-dev/use-arduino-libraries-with-the-rasperry-pi-pico-c-c-sdk-eff55c

reference(markdown):
* https://www.jianshu.com/p/335db5716248
---
task one；声音传感器的接收与控制
          
task two: 超声波传感器
          检测距离，一定距离内，
          print("There is a target approaching")
          alert;
          led灯亮；

linux_github  https://blog.csdn.net/sasafa/article/details/125699014
版本检测  git --version
git clone + ssh路径/https路径   #拷贝一份远程仓库代码到本地

sudo apt-get install g++
g++ test.cpp -o test
sudo ./test


## qt
[qt项目的创建](https://blog.csdn.net/weixin_53312997/article/details/128631504?ops_request_misc=&request_id=&biz_id=102&utm_term=qt%E9%A1%B9%E7%9B%AE&utm_medium=distribute.pc_search_result.none-task-blog-2~all~sobaiduweb~default-7-128631504.142^v73^control,201^v4^add_ask,239^v2^insert_chatgpt&spm=1018.2226.3001.4187)  
qt项目一般也是c++项目或者c++/QML项目


---
## audio
[tutorial](https://blog.csdn.net/Tang_Chuanlin/article/details/84567395)  
[USB Audio Capture Card Grabber](https://www.amazon.co.uk/gp/buy/thankyou/handlers/display.html?purchaseId=204-7367631-7223508&ref_=chk_typ_browserRefresh&isRefresh=1)

---
## c++ unit test
* reference
  https://blog.csdn.net/u013288190/article/details/120151747